﻿
using var game = new Pacman.Game1();
game.Run();
